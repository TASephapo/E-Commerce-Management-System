﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm10 : System.Web.UI.Page
    {

        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);

        }



        public void ValidateDetails()
        {

            string Username = txtUsername.Text;
            string Password = txtPasswrd.Text;

            string Password1 = @"(?=.{9,}$)(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?\W).*$";

            bool IsPassword = Regex.IsMatch(txtPasswrd.Text, Password1);

            string Role = DropDownlistRoles.Text;

            if (Username == "")
            {
                Response.Write("<script>alert('Username is Required!')</script>");

            }
            else if (Password == "")
            {

                Response.Write("<script>alert('Password is Required!')</script>");

            }
            else if (Password != null && !IsPassword)
            {
                Response.Write("<script>alert('Insert least 9 characters long, including at least one digit, lowercase letter, uppercase letter and special character!')</script>");
            }
           
            else if (Role == "")
            {

                Response.Write("<script>alert('User Role is Required!')</script>");

            }
            else
            {
               

                    InheritanceDataContext db = new InheritanceDataContext();

                    var linqQuery = from User in db.Users
                                    where ((User.UserName.ToLower() == txtUsername.Text.ToLower()) && (User.Password1 == txtPasswrd.Text) && (User.Roles.ToLower() == DropDownlistRoles.Text.ToLower()))
                                    select new { User.UserName, User.Password1, User.Roles };


                    var Retrive = linqQuery.SingleOrDefault();
                    if (Retrive != null)
                    {

                        if (Retrive.UserName.ToLower() == txtUsername.Text.ToLower() && Retrive.Password1 == txtPasswrd.Text && Retrive.Roles ==  DropDownlistRoles.Text)
                        {
                            if (Retrive.Roles == "Store")
                            {

                                Session["UserName"] = txtUsername.Text;
                                Response.Write("<script>alert('Store Is Successfully Logged In!')</script>");
                                Server.Transfer("Categories.aspx");
                            }
                            if (Retrive.Roles == "SalesRep") 
                            {

                                Session["UserName"] = txtUsername.Text;
                                Response.Write("<script>alert('SalesRep Is Successfully Logged In!')</script>");
                                Server.Transfer("Products.aspx");

                            }
                            if (Retrive.Roles == "customer")
                            {
                                Session["UserName"] = txtUsername.Text;
                                Response.Write("<script>alert('Customer Is Successfully Logged In!')</script>");
                                Server.Transfer("CustomerViewItems.aspx");
                            }
                            

                        }
                       
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid Username or Password!')</script>");
                    }
                
                


               

            }
        }


   
        protected void btnLogin_Click1(object sender, EventArgs e)
        {

            ValidateDetails();
            




        }

    }

}