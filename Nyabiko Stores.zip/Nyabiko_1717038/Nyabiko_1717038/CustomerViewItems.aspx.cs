﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm15 : System.Web.UI.Page
    {

        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);

            if (!Page.IsPostBack)
            {
                //ViewItems();
            }
        }

       /* public void ViewItems()
        {
            SqlDataAdapter query = new SqlDataAdapter("SELECT Products.ProductID, Products.ProductName, Products.ProductDescription, Products.Quantity, Products.Price, Categories.CategoryName,  Products.Image1 FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID", currectConnection);
            DataSet ds = new DataSet();
            query.Fill(ds);
            datalistViewItems.DataSource = ds;
            datalistViewItems.DataBind();
        }
        */
        protected void datalistViewItems_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Session["AddItemProduct"] = "true";
            if (e.CommandName == "AddToCart")
            {
                DropDownList list = (DropDownList)(e.Item.FindControl("DropDownListQuantity"));
                Response.Redirect("CustomerAddCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=" + list.SelectedItem.ToString());
            }
        }

       

       

      
    }
}