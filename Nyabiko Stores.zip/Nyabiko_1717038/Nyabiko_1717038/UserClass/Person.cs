﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nyabiko_1717038.UserClass
{
    public abstract class Person
    {

        private string FirstName;

        public string FirstName1
        {
            get { return FirstName; }
            set { FirstName = value; }
        }
        private string Surname;

        public string Surname1
        {
            get { return Surname; }
            set { Surname = value; }
        }

        private string Role;

        public string Role1
        {
            get { return Role; }
            set { Role = value; }
        }
          
           
    }
}