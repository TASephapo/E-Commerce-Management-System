﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nyabiko_1717038.UserClass
{
    public class Store : Person
    {
        private string Email;

        public string Email1
        {
            get { return Email; }
            set { Email = value; }
        }
        private string Username;

        public string Username1
        {
            get { return Username; }
            set { Username = value; }
        }
        private string Password;

        public string Password1
        {
            get { return Password; }
            set { Password = value; }
        }
    }
}