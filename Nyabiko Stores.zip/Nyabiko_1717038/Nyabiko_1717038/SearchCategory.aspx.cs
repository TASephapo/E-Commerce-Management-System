﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data; // needed for data processing
using System.Data.SqlClient;
using System.IO;

/*
 * 1717038
 * BATCH 02
 */

namespace Nyabiko_1717038
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        void PopulateGridView()
        {

            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
                SqlConnection sqlconn = new SqlConnection(connectionString);

                sqlconn.Open();
                SqlCommand sqlcomma = new SqlCommand();

                string query = "select  *  from Categories where CategoryID  like '%'+@CategoryID+'%'";
                sqlcomma.CommandText = query;
                sqlcomma.Connection = sqlconn;
                sqlcomma.Parameters.AddWithValue("CategoryID", txtSearchCategory.Text);
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(sqlcomma);
                sda.Fill(dt);



                if (!object.Equals(dt, null))
                {
                    if (dt.Rows.Count > 0)
                    {

                        GridVDisplaySearchedRecord.DataSource = dt;
                        GridVDisplaySearchedRecord.DataBind();
                        GridVDisplaySearchedRecord.Visible = true;
                        txtSearchCategory.Text = "";



                    }
                    else
                    {

                        txtSearchCategory.Text = "";
                        GridVDisplaySearchedRecord.Visible = false;
                        string message = "alert('" + " NO RECORD FOUND " + "');";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);

                        return;

                    }
                }
                sqlconn.Close();
            }
            catch (Exception ex)
            {
                Response.Write("ERROR" + ex);
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string CategoryId = txtSearchCategory.Text;
            if (CategoryId == "")
            {
                string message = "alert('" + "CategoryId is required! " + "');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
            }
            else
            {
                PopulateGridView();
            }
        }
    }
}