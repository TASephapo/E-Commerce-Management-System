﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;

/*
 * 1717038
 * BATCH 02
 */



namespace Nyabiko_1717038
{
    public partial class Order : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;
        protected void Page_Load(object sender, EventArgs e)
        {
            currectConnection = new SqlConnection(connectionString);
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection.Open();
            SqlCommand cmd = new SqlCommand("select ProductID from Products", currectConnection);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DropDownListProducts.Items.Add(new ListItem("--Select Product--", ""));
            DropDownListProducts.DataTextField = ds.Tables[0].Columns["ProductID"].ToString();
            DropDownListProducts.DataSource = ds.Tables[0];
            DropDownListProducts.DataBind();
        }

       
    }
}