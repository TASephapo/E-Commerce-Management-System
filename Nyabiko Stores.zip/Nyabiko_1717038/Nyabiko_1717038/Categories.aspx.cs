﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm6 : System.Web.UI.Page
    {

        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);
        }

        

        public void CategoryValidate()
        {
            if (txtCategoryName.Text == "")
            {

                Response.Write("<script>alert('Category Name is required!')</script>");
            }
            else if (txtCategoryDescrition.Text == "")
            {
                Response.Write("<script>alert('Category Description is required!')</script>");
            }
            else
            {

                try
                {


                    int returnValue;

                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "insert into  Categories (CategoryName, Description)" +
                                       "values(@CategoryName , @Description)";


                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = currectConnection;
                    cmd.Parameters.AddWithValue("@CategoryName", DbType.String);
                    cmd.Parameters.AddWithValue("@Description", DbType.String);


                    cmd.Parameters["@CategoryName"].Value = txtCategoryName.Text;
                    cmd.Parameters["@Description"].Value = txtCategoryDescrition.Text;


                    currectConnection.Open();
                    returnValue = cmd.ExecuteNonQuery();
                    currectConnection.Close();

                    Response.Write("<script>alert('Category is successfully added!')</script>");
                    


                }
                catch (SqlException ex)
                {

                    lblMessege.Text = "Sorry, An error occured ";
                }

            }

        }

        protected void btnCategory_Click(object sender, EventArgs e)
        {
            CategoryValidate(); 
        }


       
    }
}