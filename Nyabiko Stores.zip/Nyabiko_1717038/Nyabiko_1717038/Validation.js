﻿
function ValidateUser() {


    var firstName, Surname, Username, Password, Email, Role;

    firstName = document.getElementById("txtFirstname").value;
    Surname = document.getElementById("txtSurname").value;
    Username = document.getElementById("txtUsername").value;
    Email = document.getElementById("txtEmailaddress").value;
    Password = document.getElementById("enterPass").value;
    
    Role = document.getElementById("DropDownlistRoles").value;
  

    if (firstName == "")
    {
        alert("First Name is required!");
        return false;

    }
    if (Surname == "")
    {

        alert("SurName is required!");
        return false;

    }
    if (Username == "")
    {
        alert("User Name is required!");
        return false;

    }

    if (Email == "") {
        alert("Email Address is required!");
        return false;

    }
    if (Password == "")
    {
        alert("Password is required!");
        return false;

    }
   
    if (Role == "")
    {
        alert("Role is required!")

    }
   
}


function validateCategory() {

    var CategoryName, Description;

    CategoryName = document.getElementById("txtCategoryName").value;
    Description = document.getElementById("txtCategoryDescrition").value;

    if (CategoryName == "") {
        alert("Category Name is required!");
        return false;

    }
    if (Description == "") {
        alert("Category Description is required!");
        return false;
    }
}

function ValidateProduct()
{
    var ProductName, Description, price, category;

    ProductName = document.getElementById("txtProductName").value;
    Description = document.getElementById("txtDescriptionProduct").value;
    price = document.getElementById("txtPrice").value;
    
    // = document.getElementById("DropDownListCategory").value;


    if (ProductName == "")
    {
        alert("Product Name is required, Please Enter Product Name");
        return false;

    }
    if (Description == "")
    {
        alert("Product Description is required, Please Enter Product Description");
        return false;

    }
    if (price == "")
    {
        alert("Product price is required, Please Enter Product price");
        return false;

    }
  
   
}


function validateLogin() {

    var UserName, Password;

    UserName = document.getElementById("txtUsername").value;
    Password = document.getElementById("enterPass").value;

    if (UserName == "")
    {

        alert("Please Enter Username");
        return false;

    }
    if (Password == "")
    {
        alert("Please Enter Password");
        return false;
    }
}

