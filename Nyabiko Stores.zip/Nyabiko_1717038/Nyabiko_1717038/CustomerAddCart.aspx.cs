﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm19 : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;

        protected void Page_Load(object sender, EventArgs e)
        {

            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

            currectConnection = new SqlConnection(connectionString);
            if (!IsPostBack)
            {
                if(Session["buyProducts"] == null)
                {
                    btnPlaceOrder.Enabled = false;
                }
                else
                {
                    btnPlaceOrder.Enabled = true;
                }

                Session["AddItemProduct"] = "false";
                DataTable dt = new DataTable();
                DataRow row;
                dt.Columns.Add("OrderNumber");
                dt.Columns.Add("ProductID");
                dt.Columns.Add("ProductName");
                dt.Columns.Add("Image1");
                dt.Columns.Add("Price");
                dt.Columns.Add("CategoryID");
                dt.Columns.Add("quantity");
                dt.Columns.Add("CostPrice");
                dt.Columns.Add("totalPrice");

                if(Request.QueryString["id"] != null)
                {
                    if (Session["BuyProducts"] == null)
                    {
                        row = dt.NewRow();
                        SqlDataAdapter sqlSelect = new SqlDataAdapter("SELECT * FROM Products WHERE ProductID=" + Request.QueryString["id"], currectConnection);
                        DataSet dataSet = new DataSet();
                        sqlSelect.Fill(dataSet);

                        row["OrderNumber"] = 1;
                        row["ProductID"] = dataSet.Tables[0].Rows[0]["ProductID"].ToString();
                        row["ProductName"] = dataSet.Tables[0].Rows[0]["ProductName"].ToString();
                        row["Image1"] = dataSet.Tables[0].Rows[0]["Image1"].ToString();
                        row["Price"] = dataSet.Tables[0].Rows[0]["Price"].ToString();
                        row["CategoryID"] = dataSet.Tables[0].Rows[0]["CategoryID"].ToString();
                        row["Price"] = dataSet.Tables[0].Rows[0]["Price"].ToString();
                        row["quantity"] = Request.QueryString["quantity"];

                        double price = Convert.ToDouble(dataSet.Tables[0].Rows[0]["Price"].ToString());
                        int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                        double totalPrice = price * quantity;
                        row["totalPrice"] = totalPrice;

                        dt.Rows.Add(row);
                        ProductGrid.DataSource = dt;
                        ProductGrid.DataBind();
                        Session["buyProducts"] = dt;
                        btnPlaceOrder.Enabled = true;

                        ProductGrid.FooterRow.Cells[6].Text = "Total Amount";
                        ProductGrid.FooterRow.Cells[7].Text = CalculateTotal().ToString();
                        Response.Redirect("CustomerAddCart.aspx");
                    }
                    else
                    {
                        dt = (DataTable)Session["buyProducts"];
                        int orderNo;
                        orderNo = dt.Rows.Count;

                        row = dt.NewRow();

                        SqlDataAdapter sqlSelect = new SqlDataAdapter("SELECT * FROM Products WHERE ProductID=" + Request.QueryString["id"], currectConnection);
                        DataSet dataSet = new DataSet();
                        sqlSelect.Fill(dataSet);

                        row["OrderNumber"] = orderNo + 1;
                        row["ProductID"] = dataSet.Tables[0].Rows[0]["ProductID"].ToString();
                        row["ProductName"] = dataSet.Tables[0].Rows[0]["ProductName"].ToString();
                        row["Image1"] = dataSet.Tables[0].Rows[0]["Image1"].ToString();
                        row["CategoryID"] = dataSet.Tables[0].Rows[0]["CategoryID"].ToString();
                        row["Price"] = dataSet.Tables[0].Rows[0]["Price"].ToString();
                        row["quantity"] = Request.QueryString["quantity"];

                        double price = Convert.ToDouble(dataSet.Tables[0].Rows[0]["Price"].ToString());
                        int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                        double totalPrice = price * quantity;
                        row["totalPrice"] = totalPrice;

                        dt.Rows.Add(row);
                        ProductGrid.DataSource = dt;
                        ProductGrid.DataBind();
                        Session["buyProducts"] = dt;
                        btnPlaceOrder.Enabled = true;

                        ProductGrid.FooterRow.Cells[6].Text = "Total Amount";
                        ProductGrid.FooterRow.Cells[7].Text = CalculateTotal().ToString();
                        Response.Redirect("CustomerAddCart.aspx");
                    }
                }
                else
                {
                    dt = (DataTable)Session["buyProducts"];
                    ProductGrid.DataSource = dt;
                    ProductGrid.DataBind();
                    if (ProductGrid.Rows.Count > 0)
                    {
                        ProductGrid.FooterRow.Cells[5].Text = "Total Amount";
                        ProductGrid.FooterRow.Cells[6].Text = CalculateTotal().ToString();
                    }
                }
            }
            string orderDate = DateTime.Now.ToShortDateString();
            Session["OrderDate"] = orderDate;
            //orderID();


            
        }


        public double CalculateTotal()
        {
            DataTable dt = new DataTable();
            dt = (DataTable)Session["buyProducts"];
            int Count = dt.Rows.Count;
            int i = 0;
            double TotalAmount= 0.00;
            while (i < Count)
            {
                TotalAmount = TotalAmount + Convert.ToDouble(dt.Rows[i]["totalPrice"].ToString());
                i = i + 1;
            }
            return TotalAmount;
        }

        protected void ProductGrid_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            DataTable dt = new DataTable();
             dt = (DataTable)Session["buyProducts"];
             dt.Rows[e.RowIndex].Delete();
             ProductGrid.DataSource = dt.DefaultView;
            ProductGrid.DataBind();
            if (dt.Rows.Count == 0)
            {
                Response.Write("<script>alert('Sorry there are no Items In Card!')</script>");

            }
            
            
        }

        protected void ProductGrid_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow OrderNumber = ProductGrid.SelectedRow;
            GridViewRow ProductID = ProductGrid.SelectedRow;
            GridViewRow quantity = ProductGrid.SelectedRow;
            GridViewRow totalPrice = ProductGrid.SelectedRow;
            TxtOrderId.Text =  (string)ProductGrid.DataKeys[OrderNumber.RowIndex]["OrderNumber"];
            txtProductId.Text = (string)ProductGrid.DataKeys[ProductID.RowIndex]["ProductID"];
            txtQuantity.Text = (string)ProductGrid.DataKeys[quantity.RowIndex]["quantity"];
            txtAmount.Text = (string)ProductGrid.DataKeys[totalPrice.RowIndex]["totalPrice"];
            
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            try
            {


                int returnValue;

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into  Orders (OrderNumber, ProductID ,Quantity, OrderDate,TotalAmount)" +
                                   "values(@OrderNumber , @ProductID, @Quantity, @OrderDate,@TotalAmount)";


                cmd.CommandType = CommandType.Text;
                cmd.Connection = currectConnection;
                cmd.Parameters.AddWithValue("@OrderNumber", DbType.String);
                cmd.Parameters.AddWithValue("@ProductID", DbType.String);
                cmd.Parameters.AddWithValue("@Quantity", DbType.String);
                cmd.Parameters.AddWithValue("@OrderDate", DbType.String);
                cmd.Parameters.AddWithValue("@TotalAmount", DbType.String);




                cmd.Parameters["@OrderNumber"].Value =TxtOrderId.Text;
                cmd.Parameters["@ProductID"].Value = txtProductId.Text;
                cmd.Parameters["@Quantity"].Value = txtQuantity.Text;
                cmd.Parameters["@OrderDate"].Value = txtOrderDate.Text;
                cmd.Parameters["@TotalAmount"].Value =txtAmount.Text;
                

                currectConnection.Open();
                returnValue = cmd.ExecuteNonQuery();
                currectConnection.Close();

                Response.Write("<script>alert('Order is successfully placed!')</script>");
                


            }
            catch (SqlException ex)
            {

                Response.Write("<script>alert('Sorry, An error occured!')</script>");

            }

        }

        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment.aspx");
        }

       
        
        

     
    }

}