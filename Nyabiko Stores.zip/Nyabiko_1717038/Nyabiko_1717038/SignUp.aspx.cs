﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm8 : System.Web.UI.Page
    {

       
        


        protected void Page_Load(object sender, EventArgs e)
        {

            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }


        public void ValidateDetails()
        {

            
 
            string Password1 = @"(?=.{9,}$)(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?\W).*$";

            bool IsPassword = Regex.IsMatch(txtPasswrd.Text,Password1);

            string FirstName = txtFirstname.Text;

            string Surname = txtSurname.Text;

            string Username = txtUsername.Text;

            string EmailAddress = txtEmailaddress.Text;

            string Password = txtPasswrd.Text;




            if (FirstName == "")
            {

                Response.Write("<script>alert('First Name is Required!')</script>");
            }
            else if (Surname == "")
            {

                Response.Write("<script>alert('Surname is Required!')</script>");
            }
            else if (Username == "")
            {

                Response.Write("<script>alert('Username is Required!')</script>");
            }
            else if (EmailAddress == "")
            {

                Response.Write("<script>alert('Email Address is Required!')</script>");

            }
            else if (Password == ""  )
            {
                
                Response.Write("<script>alert(' Password is Required! ')</script>");

                
            }
            else if (Password != null && !IsPassword)
            {
                Response.Write("<script>alert('Insert least 9 characters long, including at least one digit, lowercase letter, uppercase letter and special character!')</script>");
            }

            else
            {

                var db = new InheritanceDataContext();

                if (btnRegister.Text == "Register")
                {



                    var linqQuery = from User in db.Users
                                    where (User.Email.ToLower() == txtEmailaddress.Text.ToLower())
                                    select new { User.Email };

                    var Retrive = linqQuery.SingleOrDefault();

                    if (Retrive != null)
                    {
                        if ((Retrive.Email.ToLower() == txtEmailaddress.Text.ToLower()))
                        {

                            Response.Write("<script>alert('Inserted Email Address Already Exists!')</script>");
                        }

                    }
                    else
                    {
                        using (db)
                        {
                            customer customer = new customer
                            {
                                FirstName = txtFirstname.Text,
                                Surname = txtSurname.Text,
                                UserName = txtUsername.Text,
                                Password1 = txtPasswrd.Text,
                                Email = txtEmailaddress.Text

                            };
                            db.Users.InsertOnSubmit(customer);
                            db.SubmitChanges();
                            Response.Write("<script>alert('You Are successfully Registered!')</script>");
                            Server.Transfer("Login.aspx");
                        }
                    }




                }


            }
        }

        protected void btnLogin_Click1(object sender, EventArgs e)
        {

            ValidateDetails();

           

            
            /*
                  
                     
                      if (txtRole.Text == "SalesRep")
                      {
                          SalesRep salesRep = new SalesRep
                          {

                              FirstName = txtFirstname.Text,
                              Surname = txtSurname.Text,
                              UserName = txtUsername.Text,
                              Password1 = txtPasswrd.Text,
                              Email = txtEmailaddress.Text
                          };

                          db.Users.InsertOnSubmit(salesRep);
                          db.SubmitChanges();
                          string message = "alert('" + "SalesRep is Successfully Registered! " + "');";
                          ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                          return;

                      }
                      else if (txtRole.Text == "Customer")
                      {
                          customer customer = new customer
                          {
                              FirstName = txtFirstname.Text,
                              Surname = txtSurname.Text,
                              UserName = txtUsername.Text,
                              Password1 = txtPasswrd.Text,
                              Email = txtEmailaddress.Text

                          };

                          db.Users.InsertOnSubmit(customer);
                          db.SubmitChanges();
                          string message = "alert('" + "Customer is Successfully Registered! " + "');";
                          ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                          return;
                      }
                      else if (txtRole.Text == "Store")
                      {
                          Store store = new Store
                          {
                              FirstName = txtFirstname.Text,
                              Surname = txtSurname.Text,
                              UserName = txtUsername.Text,
                              Password1 = txtPasswrd.Text,
                              Email = txtEmailaddress.Text

                          };
                          db.Users.InsertOnSubmit(store);
                          db.SubmitChanges();
                          string message = "alert('" + "Store is Successfully Registered! " + "');";
                          ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                          return;

                      }

                  }
              }
              else
              {
                  string message = "alert('" + " Not Registered! " + "');";
                  ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                  return;
              }
              
   */
               

            
        }
    }
}
 
