﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        private string uploadDirectory;

        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);
            // Place files in a website subfolder named Images.
            uploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "Images");

            if (!IsPostBack)
            {


                currectConnection.Open();
                SqlCommand cmd = new SqlCommand("select CategoryID from Categories", currectConnection);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DropDownListCategory.Items.Add(new ListItem("--Select Category--", ""));
                DropDownListCategory.DataTextField = ds.Tables[0].Columns["CategoryID"].ToString();
                DropDownListCategory.DataSource = ds.Tables[0];
                DropDownListCategory.DataBind();

                currectConnection.Close();
            }


        }


        public void Validate()
        {



            if (fileuploadImage.PostedFile.FileName == "")
            {
                string message = "alert('" + "No Image is specified " + "');";
                ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                return;

            }
            else
            {

                string extension = Path.GetExtension(fileuploadImage.PostedFile.FileName);
                switch (extension.ToLower())
                {
                    case ".png":
                        break;

                    case ".jpg":
                        break;

                    case ".bmp":
                        break;

                    case ".tip":
                        break;

                    case ".gif":
                        break;

                    case ".jpeg":
                        break;
                    default:

                        string message = "alert('" + "Only Image files are required" + "');";
                        ClientScript.RegisterStartupScript(this.GetType(), "Error_Message", message, true);
                        return;

                }

                string serverFileName = Path.GetFileName(fileuploadImage.PostedFile.FileName);
                string fullUploadPath = Path.Combine(uploadDirectory, serverFileName);
                try
                {
                    fileuploadImage.PostedFile.SaveAs(fullUploadPath);
                    //lblMessage.Text = "File " + serverFileName;



                }
                catch (Exception err)
                {
                    lblMessage.Text = err.Message;
                }

            }
            try
            {


                int returnValue;

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into  Products(ProductName, ProductDescription,Price, Image1, Quantity, CategoryID)" +
                                   "values(@ProductName , @ProductDescription, @Price, @Image1, @Quantity, @CategoryID )";


                cmd.CommandType = CommandType.Text;
                cmd.Connection = currectConnection;
                cmd.Parameters.AddWithValue("@ProductName", DbType.String);
                cmd.Parameters.AddWithValue("@ProductDescription", DbType.String);
                cmd.Parameters.AddWithValue("@Price", DbType.String);
                cmd.Parameters.AddWithValue("@Image1", DbType.String);
                cmd.Parameters.AddWithValue("@Quantity", DbType.String);
                cmd.Parameters.AddWithValue("@CategoryID", DbType.String);



                cmd.Parameters["@ProductName"].Value = txtProductName.Text;
                cmd.Parameters["@ProductDescription"].Value = txtDescriptionProduct.Text;
                cmd.Parameters["@Price"].Value = float.Parse(txtPrice.Text);
                cmd.Parameters["@Image1"].Value = fileuploadImage.FileName;
                cmd.Parameters["@Quantity"].Value = TxtQuantity.Text;
                cmd.Parameters["@CategoryID"].Value = DropDownListCategory.Text;

                currectConnection.Open();
                returnValue = cmd.ExecuteNonQuery();
                currectConnection.Close();

                Response.Write("<script>alert('Product is successfully added!')</script>");

               


            }
            catch (SqlException ex)
            {

                Response.Write("<script>alert('Sorry, An error occured!')</script>");

            }


        }

        protected void btnProduct_Click1(object sender, EventArgs e)
        {
            Validate();
        }
    
    }
}