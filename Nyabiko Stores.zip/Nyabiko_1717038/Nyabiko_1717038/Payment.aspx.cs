﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);

            if (!IsPostBack)
            {


                currectConnection.Open();
                DropdownListOrderNumber.Items.Add(new ListItem("--Select Order Number--", ""));
                SqlCommand cmd = new SqlCommand("select OrderNumber from Orders", currectConnection);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                DropdownListOrderNumber.Items.Add(new ListItem("--Select Order Number--", ""));

                da.Fill(ds);

                DropdownListOrderNumber.DataTextField = ds.Tables[0].Columns["OrderNumber"].ToString();
                DropdownListOrderNumber.DataSource = ds.Tables[0];
                DropdownListOrderNumber.DataBind();

                currectConnection.Close();

                

                
            }



        }

       

        protected void RadioButtonLstPaymentMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            

            if ((string.Equals(RadioButtonLstPaymentMethod.SelectedValue, "Mpesa")))
            {

                txtCardNumber.Attributes.Add("placeholder", "Enter Vodacom Mobile Number");
                txtCardNumber.Visible = true;
                txtPayment.Visible = true;
                txtCardNumber.Focus();
               


            }
          
            if ((string.Equals(RadioButtonLstPaymentMethod.SelectedValue, "EcoCash")))
            {
                    txtCardNumber.Attributes.Add("placeholder", "Enter Econet Mobile Number ");
                    txtCardNumber.Visible = true;
                    txtPayment.Visible = true;
                
                    txtCardNumber.Focus();

                   
            }
           if((string.Equals(RadioButtonLstPaymentMethod.SelectedValue,"Bank")))
            {

                    txtCardNumber.Attributes.Add("placeholder", "Enter Bank Account Number ");
                    txtCardNumber.Visible = true;
                    txtPayment.Visible = true;
                    txtCardNumber.Focus();
             }
                

                
            
        }


          public void Insert()
         {
            try
            {


                int returnValue;

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "insert into  Payment (OrderNumber,CardNumber, CardType, Amount)" +
                                   "values(@OrderNumber , @CardNumber,@CardType,@Amount)";


                cmd.CommandType = CommandType.Text;
                cmd.Connection = currectConnection;
                cmd.Parameters.AddWithValue("@OrderNumber", DbType.String);
                cmd.Parameters.AddWithValue("@CardNumber", DbType.String);
                cmd.Parameters.AddWithValue("@CardType", DbType.String);
                cmd.Parameters.AddWithValue("@Amount", DbType.String);

                cmd.Parameters["@OrderNumber"].Value = DropdownListOrderNumber.Text;
                cmd.Parameters["@CardNumber"].Value = txtCardNumber.Text;
                cmd.Parameters["@CardType"].Value = RadioButtonLstPaymentMethod.Text;
                cmd.Parameters["@Amount"].Value = txtPayment.Text;


                currectConnection.Open();
                returnValue = cmd.ExecuteNonQuery();
                currectConnection.Close();

                Response.Write("<script>alert('Payment is successfully made!')</script>");

                txtCardNumber.Text = "";
                txtPayment.Text = "";


            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('Sorry,An error occured!')</script>");
              
            }

         }

       
           

            
        

        protected void btnPayment_Click(object sender, EventArgs e)
        {

            string CardNumber = @"(?<!\d)\d{12}(?!\d)";
            string MpesaNumber = @"(^[5]\d{7}$)";
            string BuddieNumber = @"(^[6]\d{7}$)";

            bool IsMpesa = Regex.IsMatch(txtCardNumber.Text, MpesaNumber);
            bool IsBuddie = Regex.IsMatch(txtCardNumber.Text, BuddieNumber);
            bool IsCard = Regex.IsMatch(txtCardNumber.Text, CardNumber);


            if (txtCardNumber.Text == "")
            {


                Response.Write("<script>alert('Card No is required!')</script>");

            }
            else if (txtPayment.Text == "")
            {
                Response.Write("<script>alert('Please Enter Payment Amount!')</script>");


            }
            else if (RadioButtonLstPaymentMethod.Text == "")
            { 

                    Response.Write("<script>alert('Please Select Payment Method!')</script>");
            }
            else
            {

                    if ((string.Equals(RadioButtonLstPaymentMethod.SelectedValue, "Mpesa")))
                    {

                        if (!IsMpesa)
                        {
                            Response.Write("<script>alert('Your Mobile Number should be of 8 digits and Start with 5!')</script>");
                            txtCardNumber.Text = "";
                            txtPayment.Text = "";


                        }
                        else
                        {
                                    Insert();
                        }
                    }
                    if ((string.Equals(RadioButtonLstPaymentMethod.SelectedValue, "EcoCash")))
                    {
                        if (!IsBuddie)
                        {
                            Response.Write("<script>alert('Your Mobile Number should be of 8 digits and start with 6!')</script>");
                            txtCardNumber.Text = "";
                            txtPayment.Text = "";


                        }
                        else
                        {
                            Insert();
                        }
                    }
                    if ((string.Equals(RadioButtonLstPaymentMethod.SelectedValue, "Bank")))
                    {
                        if (!IsCard)
                        {
                            Response.Write("<script>alert('Your Card Number should be  12 digits !')</script>");
                            txtCardNumber.Text = "";
                            txtPayment.Text = "";


                        }
                        else
                        {
                                Insert();
                        }
                    }
                }
            }
           
       


        }

 }
