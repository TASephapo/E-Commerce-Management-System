﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm5 : System.Web.UI.Page
    {

      

        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;

        string ProductName, ProductDescription, CategoryName,  Quantity ,Image1, Price, ProductID;

        int ID;
        protected void Page_Load(object sender, EventArgs e)
        {
            currectConnection = new SqlConnection(connectionString);
            if (Request.QueryString["ID"] == null)
            {

                Response.Redirect("CustomerViewItems.aspx");

            }
            else
            {
                ID = Convert.ToInt32(Request.QueryString["ID"].ToString());
                currectConnection.Open();
                SqlCommand cmd = currectConnection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT Products.ProductID, Products.ProductName, Products.ProductDescription, Products.Price,Products.Quantity, Categories.CategoryName, Products.Image1  FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE Products.ProductID =" + ID + "";

                 cmd.ExecuteNonQuery();
                 DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                d1.DataSource = dt;
                d1.DataBind();

                currectConnection.Close();


            }

        }

        protected void BtnAddCart_Click(object sender, EventArgs e)
        {
            currectConnection.Open();
            SqlCommand cmd = currectConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT Products.ProductID, Products.ProductName, Products.ProductDescription, Products.Price,Products.Quantity, Categories.CategoryName, Products.Image1  FROM Products INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE Products.ProductID =" + ID + "";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            da.Fill(dt);
            d1.DataSource = dt;
            d1.DataBind();
            
            foreach (DataRow rows in dt.Rows)
            {
               

               
                ProductID = rows["ProductID"].ToString();
                ProductName = rows["ProductName"].ToString();
                ProductDescription = rows["ProductDescription"].ToString();
                Price = rows["Price"].ToString();
                Quantity = rows["Quantity"].ToString();
                CategoryName = rows["CategoryName"].ToString();
                Image1 = rows["Image1"].ToString();


            }

            currectConnection.Close();
           

            if (Request.Cookies["Cookie"] == null)
            {
                Response.Cookies["Cookie"].Value = ProductID.ToString() + "," + ProductName.ToString() + "," + ProductDescription.ToString() + "," + Price.ToString() + "," + CategoryName.ToString() + "," + Image1.ToString();
                Response.Cookies["Cookie"].Expires = DateTime.Now.AddMinutes(20);

            }
            else
            {

                Response.Cookies["Cookie"].Value = Request.Cookies["Cookie"].Value + "|" + ProductID.ToString() + "," + ProductName.ToString() + "," + ProductDescription.ToString() + "," + Price.ToString() + "," + CategoryName.ToString() + "," + Image1.ToString();
                Response.Cookies["Cookie"].Expires = DateTime.Now.AddMinutes(20);

            }
            Response.Redirect("ProductCart.aspx");

            

        }

       
    }
}