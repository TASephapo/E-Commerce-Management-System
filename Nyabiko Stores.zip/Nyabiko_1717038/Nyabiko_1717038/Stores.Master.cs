﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data; // needed for data processing
using System.Data.SqlClient;
using System.IO;

namespace Nyabiko_1717038
{
    public partial class Stores : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["UserName"] != null)
            {
                lblUsername.Text = "Welcome: " + Session["UserName"].ToString();

            }
           
        }


    }
}
