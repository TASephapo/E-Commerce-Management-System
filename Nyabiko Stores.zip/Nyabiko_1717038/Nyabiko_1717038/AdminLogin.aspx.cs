﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm22 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



        }

        public void ValidateDetails()
        {

            string Username = txtUsername.Text;
            string Password = txtPasswrd.Text;


            string Password1 = @"(?=.{9,}$)(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?\W).*$";

            bool IsPassword = Regex.IsMatch(txtPasswrd.Text, Password1);

            

            if (Username == "")
            {
                Response.Write("<script>alert('Username is Required!')</script>");

            }
            else if (Password == "")
            {

                Response.Write("<script>alert('Password is Required!')</script>");

            }
            else if (Password != null && !IsPassword)
            {
                Response.Write("<script>alert('Insert least 9 characters long, including at least one digit, lowercase letter, uppercase letter and special character!')</script>");
            }
           
            else
            {
                


                    InheritanceDataContext db = new InheritanceDataContext();

                    var linqQuery = from Admin1 in db.Admin1s
                                    where ((Admin1.Username.ToLower() == txtUsername.Text.ToLower()) && (Admin1.Password2 == txtPasswrd.Text))
                                    select new { Admin1.Username, Admin1.Password2 };


                    var Retrive = linqQuery.SingleOrDefault();

                    if (Retrive != null)
                    {

                        Session["UserName"] = txtUsername.Text;

                        Response.Redirect("AdminAddUser.aspx");

                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid Username or Password!')</script>");

                    }

            }

        }

       

        protected void btnLogin_Click1(object sender, EventArgs e)
        {

            ValidateDetails();

        }

       
       
    }
}