﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 * 1717038
 * BATCH 02
 */


namespace Nyabiko_1717038
{
    public partial class WebForm24 : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["NyabikoConn"].ConnectionString;
        SqlConnection currectConnection;

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            currectConnection = new SqlConnection(connectionString);
        }


        public void ValidateUser()
        {
            string Password1 = @"(?=.{9,}$)(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?\W).*$";

            bool IsPassword = Regex.IsMatch(txtPasswrd.Text,Password1);

            if (txtUsername.Text == "")
            {
           
                Response.Write("<script>alert('UserName is Required!')</script>");
                
            }
            else if (txtPasswrd.Text == "")
            {
                Response.Write("<script>alert('Password is Required!')</script>");
            }
            else if (txtPasswrd.Text != null && !IsPassword)
            {
                Response.Write("<script>alert('Insert least 9 characters long, including at least one digit, lowercase letter, uppercase letter and special character!')</script>");
            }
            else
            {
                try
                {


                    int returnValue;

                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "insert into  Admin1 (Username, Password2)" +
                                       "values(@Username , @Password2)";


                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = currectConnection;
                    cmd.Parameters.AddWithValue("@Username", DbType.String);
                    cmd.Parameters.AddWithValue("@Password2", DbType.String);


                    cmd.Parameters["@Username"].Value = txtUsername.Text;
                    cmd.Parameters["@Password2"].Value = txtPasswrd.Text;


                    currectConnection.Open();
                    returnValue = cmd.ExecuteNonQuery();
                    currectConnection.Close();

                    Response.Write("<script>alert('New Admin is successfully added!')</script>");


                }
                catch (SqlException ex)
                {
                    Response.Write("<script>alert('Sorry, An error occured!')</script>");
                   
                }

            }

        }

        protected void btnLogin_Click1(object sender, EventArgs e)
        {
            ValidateUser();
        }
    }
}